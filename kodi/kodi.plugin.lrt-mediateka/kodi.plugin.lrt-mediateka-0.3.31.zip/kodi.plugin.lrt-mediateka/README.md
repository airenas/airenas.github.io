# [LRT mediateka](http://www.lrt.lt/mediateka) įskiepis

## Aprašymas
Paprastas Kodi įskiepis žiūrėti video iš LRT mediatekos. 
Sukonfigūruotos tik kelios statinės kategorijos: Panorama, Sportas, Filmai.

## Diegimas
- Parsisiųskite paskutinės versijos **kodi.plugin.lrt-mediateka.x.x.x.zip** failą iš [github.com/airenas/kodi.plugin.lrt-mediateka/releases](https://github.com/airenas/kodi.plugin.lrt-mediateka/releases).

- Instaliuokite pagal Kodi instrukcijas. Žr.: [https://kodi.wiki/view/HOW-TO:Install_add-ons_from_zip_files](https://kodi.wiki/view/HOW-TO:Install_add-ons_from_zip_files).

## Licenzijos
Ikona ir kiti paveikslėliai yra [LRT](http://www.lrt.lt) nuosavybė!

Copyright © 2021, [Airenas Vaičiūnas](https://github.com/airenas).

